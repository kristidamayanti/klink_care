<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?><div class="row-fluid">
    <div class="span12 subnav">
        <div class="span5 alex menu"><h2>K-Link Care Founder</h2></div>
        <div class="span4 menu offset3 pull-right"><p>home > K-Link Care Founder</p></div>          
    </div>
</div>

<div class="row-fluid">          
    <div class="span7">
        <br>
        <div class="thumbnail">
            <img data-src="holder.js/573x318" alt="">
        </div>
        <h3 class="alex white">Message From The Founder</h3>
        <p>Kepedulian K-Link terhadap masalah sosial dan kemanusiaan telah berlangsung sejak masa-masa awal berdirinya, K-Link secara rutin membuat pos-pos dana untuk kegiatan sosial dan kemanusiaan. Manajemen K-Link memiliki pandangan bahwa sebagai bagian dari masyarakat Indonesia K-Link harus berkontribusi terhadap kemajuan kesejahteraan masyarakat Indonesia secara umum. Hal ini yang mendorong K-Link untuk membentuk Yayasan K-Link Peduli atau K-Link Care Foundation, agar kegiatan-kegiatan sosial dan kemanusiaan tersebut dapat lebih terorganisir dengan baik dan dapat menjangkau lebih banyak pihak yang membutuhkan. </p>
        <p>K-Link Care merupakan yayasan nirlaba yang dibentuk oleh K-Link bertujuan sebagai wadah manifestasi corporate social responsibility. Program-progam K-Link Care Foundation bersifat sosial kemanusiaan dan pendidikan. Salah satu program K-Link Care adalah membantu pengembangan pendidikan untuk anak-anak usia sekolah dengan cara pemberian beasiswa pendidikan untuk siswa-siswa berprestasi dari keluarga kurang mampu, pemberian beasiswa K-Link Care untuk 50 siswa SMP dan SMU telah berlangsung dari tahun 2012. Untuk program kemanusiaan, K-Link Care Foundation senantiasa memberikan bantuan  makanan, obat-obatan dan alat-alat tulis untuk korban-korban bencana-bencana alam di Indonesia seperti bantuan untuk korban banjir Jakarta pada tahun 2013, gempa di Aceh yang terjadi pada tahun 2013 dan Bencana Gunung Api Sinabung 2014. K-Link Care Foundation membentuk K-Link CADS Center sebagai pusat terapi untuk anak-anak berkebutuhan khusus dari keluarga kurang mampu.</p>
    </div>

    <div class="span4">
        <br>
        <div class="thumbnail">
            <img data-src="holder.js/316x200" alt="">
        </div>
        <div class="widget">
            <h3 class="alex">Information</h3>
            <p>K-LINK CARE FOUNDATION adalah Yayasan yang bergerak dibidang sosial,
                bertujuan untuk membantu masyarakat yang kurang mampu.</p>
            <p>Anda dapat melakukan donasi ke Rek BCA NO 450.307.8816 A/N YAYASAN K-LINK PEDULI </p>
        </div>
        <div class="widget">
            <h4 class="alex">General Inquiries</h4>

            <ul>
                <li> <i class="icon-map-marker"></i> K-LINK Tower Lt. 11. </li>
                <li> Jl Gatot Subroto Kav.59A Jakarta Selatan 12950</li>
            </ul>

            <ul>
                <li><i class="icon-headphones"></i> <p>+62 21 29027000</p></li>
                <li><i class="icon-envelope "></i> <p> info@k-linkcare.com</p></li>
                <li><i class="icon-globe"></i> <p> www.k-linkcare.com</p></li>
            </ul>

        </div>

        <div class="widget">
            <h4 class="alex">Business Hours</h4>
            <ul>
                <li><i class="icon-time"></i> Monday - Friday <span class="hours">8 am to 4 pm</span></li>
                <li><i class="icon-time"></i> Saturday <span class="hours">9 am to 2 pm</span></li>
                <li><i class="icon-ban-circle"></i> Sunday <span class="hours">Closed</span></li>
            </ul>
        </div>
    </div>
</div>

<hr>

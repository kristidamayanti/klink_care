<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="footer">
    <p>&copy; K-Link Care Foundation 2013 - 2013</p>
</div>

</div> <!-- /container -->

<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="<?php echo base_url() ?>bootstrap/js/jquery-1.10.2.min.js"></script>
<script src="<?php echo base_url() ?>bootstrap/js/bootstrap.js"></script>
<script src="<?php echo base_url() ?>bootstrap/js/holder.js"></script>
<script> Holder.add_theme("bright", {background: "white", foreground: "gray", size: 12})</script>    
<script src="<?php echo base_url() ?>bootstrap/js/jquery.backstretch.min.js"></script>
<script type="text/javascript">
    $.backstretch("<?php echo base_url() ?>images/bg.jpg");
</script>
</body>
</html>

<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<body>
    <div class="container">
        <div class="masthead">
            <div class="logo"><img alt="" src="<?php echo base_url(); ?>images/logo.png"> </div>
            <h3 class="muted"></h3>        
            <div class="navbar">
                <div class="navbar-inner">            
                    <ul class="nav">
                        <?php
                        if (count($mHeader) > 0):
                            foreach ($mHeader->result() as $hMenu):

                                if ($hMenu->menu_url == null):
                                    echo "<li>" . anchor($hMenu->menu_url, $hMenu->menu_title) . "\n";
                                else:
                                    echo "<li class='dropdown'>" . "\n";
                                    echo "<a class='dropdown-toggle' data-toggle='dropdown' href='#'>" . $hMenu->menu_title . " </a>" . "\n";
                                endif;

                                if (count($mChild) > 0):
                                    echo "<ul class='dropdown-menu'>" . "\n";
                                    foreach ($mChild->result() as $cMenu):
                                        if ($hMenu->menu_category == $cMenu->menu_category):
                                            echo "<li>" . anchor($cMenu->menu_url, $cMenu->menu_title) . "</li>" . "\n";
                                        endif;
                                    endforeach;
                                    echo "</ul>" . "\n";
                                endif;

                                echo "</li>" . "\n";
                            endforeach;
                        endif;
                        ?>                                                    
                    </ul>
                </div>          
            </div><!-- /.navbar -->
        </div>

        <div id="myCarousel" class="carousel slide">
            <ol class="carousel-indicators">
                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                <li data-target="#myCarousel" data-slide-to="1"></li>
                <li data-target="#myCarousel" data-slide-to="2"></li>
            </ol>
            <!-- Carousel items -->
            <div class="carousel-inner">
                <div class="carousel-inner">
                    <?php
                    if (isset($listImgHdr)) {
                        $no = 0;
                        foreach ($listImgHdr as $datax) {
                            if ($no == 0) {
                                echo "<div class=\" active item\"><img alt=\"\" src=\"" . base_url() . "$datax->ImgName \"></div>";
                            }
                            echo "<div class=\"item\"><img alt=\"\" src=\"" . base_url() . "$datax->ImgName\"></div>";
                            $no++;
                        }
                    }
                    ?>
                </div>
            </div>
            <!-- Carousel nav -->
            <a class="carousel-control left" href="#myCarousel" data-slide="prev">&lsaquo;</a>
            <a class="carousel-control right" href="#myCarousel" data-slide="next">&rsaquo;</a>
        </div>


        <hr>

        <!-- Example row of columns -->
        <div class="row-fluid">
            <div class="span4">          
                <h2 class='alex white'>Beasiswa</h2>
                <p><img class="img-circle img-icon" src="<?php echo base_url(); ?>images/icon-anaksd.jpg"></img>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
                <p><a class="btn" href="#">View details &raquo;</a></p>
            </div>
            <div class="span4">
                <h2 class='alex white'>Charity</h2>
                <p><img class="img-circle img-icon" src="<?php echo base_url(); ?>images/icon-charity.jpg"></img>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
                <p><a class="btn" href="#">View details &raquo;</a></p>
            </div>
            <div class="span4">
                <h2 class='alex white'>News</h2>
                <?php
                $i = 0;
                if (isset($listNews)) {
                    foreach ($listNews as $data) {
                        $i++;
                        $isiNews = $data->news_description;
                        $isiNews = character_limiter($isiNews, 200);
                        $urlNews = base_url('c_news/newsMore/' . $data->news_id);

                        echo '<p><img height="140" width="140" class="img-circle img-icon" src="' . base_url() . './images/' . $data->news_img_url . '"></img>' . $isiNews . '</p>
          				  <p><a class="btn" href="' . $urlNews . '">Read More &raquo;</a></p>';
                    }
                }
                ?>
            </div>
        </div>

        <hr>      
    </div> <!-- /container -->
    <div class="footer">
        <p>&copy; K-Link Care Foundation 2013 - 2013</p>
    </div>


    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo base_url(); ?>bootstrap/js/jquery-1.10.2.min.js"></script>
    <script src="<?php echo base_url(); ?>bootstrap/js/bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>bootstrap/js/jquery.backstretch.min.js"></script>
    <script type="text/javascript">
        $.backstretch("<?php echo base_url(); ?>images/bg.jpg",
                {centeredX: true, centeredY: true, fade: 1500});
    </script>
</body>
</html>



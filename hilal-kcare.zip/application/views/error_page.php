<!-- Example row of columns -->
<div class="row-fluid">
    <div class="span12 subnav">
        <div class="alex menu"><h2>We are sorry !</h2></div>                  
    </div>
</div>

<div class="row-fluid">
    <div class="span12">
        <!-- Jumbotron -->
        <div class="jumbotron">
            <div class="donatebg">
                <?php echo img("images/404.png"); ?>                            
            </div>
        </div>
    </div>
</div>
<hr>

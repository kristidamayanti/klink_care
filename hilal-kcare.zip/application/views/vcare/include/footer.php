<?php
 echo '        <!-- Le javascript
        ================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->
        <script src="'.base_url().'bootstrap/js/jquery-1.10.2.min.js"></script>
        <script src="'.base_url().'bootstrap/js/bootstrap.js"></script>
        <script src="'.base_url().'bootstrap/js/holder.js"></script>
<script src="'.base_url().'bootstrap/js/script-menu.js"></script>
        <script> Holder.add_theme("bright", {background: "white", foreground: "gray", size: 12})</script>
        <script src="'.base_url().'bootstrap/js/jquery.backstretch.min.js"></script>
        <script type="text/javascript">
            $.backstretch("'.base_url().'images/bg.jpg");
        </script>
</html>';
?>
<?php

	echo '<div class="container">
                <ul class="nav">';
					$this->load->model('m_menu');
					$data['listMenu'] = $this->m_menu->getAllMenuHead();
					
                    foreach ($data['listMenu'] as $item){
						echo '<li><a href="'.base_url($item->menu_url).'">'.$item->menu_desc.'</a></li>';
					};
                '</ul>
            </div>';










/*
	echo '                <div class="navbar">
                    <div class="navbar-inner">
                        <div class="container">
                            <ul class="nav">
                                <li class="dropdown">
				                  <a class="dropdown-toggle" data-toggle="dropdown" href="#">Home</a>
				                  <ul class="dropdown-menu">
				                    <li><a href="#">Action</a></li>
				                    <li><a href="#">Another action</a></li>
				                    <li><a href="#">Something else here</a></li>                                
				                  </ul>
				                </li>
                                <li><a href="'.base_url('c_news').'">News</a></li>
                                <li><a href="gallery.html">Gallery</a></li>
                                <li><a href="download.html">Download</a></li>
                                <li><a href="about.html">Donate</a></li>
                                <li><a href="about.html">About</a></li>
                                <li><a href="contact.html">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                </div><!-- /.navbar -->';
			*/	
				
		
		/*		
			echo '<div class="navbar">
                    <div class="navbar-inner">
                        <div class="container">
                            <ul class="nav">';
							
			if(isset($listMenu)){
				foreach($listMenu as $data){
					$menu_desc = $data->menu_desc;
					$menu_url = base_url($data->menu_url);
					
					echo '
				             
                                <li><a href="'.$menu_url.'">'.$menu_desc.'</a></li>
                           ';
			}
			}
			
			echo ' </ul>
                        </div>
                    </div>
                </div><!-- /.navbar -->';
				*/
				
?>
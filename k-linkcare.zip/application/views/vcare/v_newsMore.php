

	<?php //echo $this->load->view('vcare/include/header'); ?>
	
    <body>
        <div class="container">
            <div class="masthead">
                <div class="logo"><img alt="" src="<?php echo base_url().'images/logo.png'; ?>"> </div>
                <h3 class="muted"></h3>
				<div class="navbar">
		        	<div class="navbar-inner">
						<?php echo $this->load->view('vcare/include/menu'); ?>
					</div>
				</div><!-- /.navbar -->
            </div>

            <!-- Example row of columns -->
            <div class="row-fluid">
                <div class="span12 subnav">
                    <div class="span4 menu"><h2>News</h2></div>                             
                </div>
            </div>
	
		<!-- ambil NEWS dari database -->
		<?php 
			$i = 0;
			if(isset($newsData)){
				foreach($newsData as $data){
					$i++;
					$isiNews = $data->news_description;
					$urlNews = '#';
					
					echo '
				            <div class="row">
				                <div class="span12">
				                    <div class="row">
				                        <div class="span8">
				                            <h3><strong><a href="'.$urlNews.'">'.$data->news_title.'</a></strong></h3>
				                        </div>
				                    </div>
				                    <div class="row">
				                        <div class="span3">
				                            <a href="'.$urlNews.'" class="thumbnail">
				                                <img src="'.base_url().'./images/'.$data->news_img_url.'" alt="">
				                            </a>
				                        </div>	  
										<div class="span8">
				                            <p>'.$isiNews.'</p>
				                        </div>
				                    </div>
				                    <div class="row">
				                        <div class="span8">
				                            <p></p>
				                            <p>
				                                <i class="icon-user"></i> by <a href="#">'.$data->news_createuser.'</a>
				                                | <i class="icon-calendar"></i>'.$data->news_createdt.'
				                                | <i class="icon-comment"></i> <a href="#">'.$data->news_comment.'</a>
				                                | <i class="icon-share"></i> <a href="#">39 Shares</a>
				                                | <i class="icon-tags"></i> Tags : <a href="#"><span class="label label-info">Snipp</span></a>
				                                <a href="#"><span class="label label-info">Bootstrap</span></a>
				                                <a href="#"><span class="label label-info">UI</span></a>
				                                <a href="#"><span class="label label-info">growth</span></a>
				                            </p>
				                        </div>
				                    </div>
				                </div> <!--span12-->                
				            </div> <!--row--> 
							<hr>';
			}
			}
		?>
		<!-- END ambil NEWS dari database -->	
			
            <div class="pagination pagination-small pagination-centered">
                <ul>
                    <li><a href="#">Prev</a></li>
                    <li><a href="#">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#">4</a></li>
                    <li><a href="#">5</a></li>
                    <li><a href="#">Next</a></li>
                </ul>
            </div>
            <div class="footer">
                <p>&copy; K-Link Care Foundation 2013 - 2013</p>
                <p>K-Link Tower 11th Floor, Jl Gatot Subroto Kav 59A, Jakarta Selatan 12910</p>
            </div>

        </div> <!-- /container -->

    </body>
</html>
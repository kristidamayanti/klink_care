// JavaScript Document

langManager.addIndexes({
error_1:'Es trat ein Fehler während der Operation auf!',
error_2:'Es existiert bereits ein Element mit dem selben Namen!',
willReload:'Die Seite wird neu geladen.',
deleteConfirm:'Sind Sie sicher, dass Sie dieses Element löschen möchten?',
doOneOperationAtATime:'Nur eine Operation kann zu jedem Zeitpunkt aktiv sein.',
operationInProcess:'Ihre Anfrage wird bearbeitet.',
selectNode2MakeOperation:'Um eine Operation durchzuführen, klicken Sie ein Element an, um es zu aktivieren!',
addDocMenu:'Seite hinzufügen',
addFolderMenu:'Ordner hinzufügen',
editMenu:'editieren',
deleteMenu:'löschen',
missionCompleted:'Die Operation wurde erfolgreich abgeschlossen',
expandAll:'Expand all',
collapseAll:'Collapse all'
});
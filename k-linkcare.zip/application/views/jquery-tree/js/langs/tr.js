// JavaScript Document

langManager.addIndexes({
error_1:'\u0130\u015Flemde bir hata olu\u015Ftu.',
error_2:'Ayn\u0131 isme sahip eleman zaten bulunmaktadır.',
willReload:'Sayfa yeniden y\u00FCklenecek.',
deleteConfirm:'Bu eleman\u0131 silmek istedi\u011Finize eminmisiniz?',
doOneOperationAtATime:'Herhangi bir i\u015Flem yap\u0131l\u0131rken ikinci farkl\u0131 bir i\u015Flem yap\u0131lamaz.',
operationInProcess:'\u0130\u015Fleminiz yerine getiriliyor.',
selectNode2MakeOperation:'\u0130\u015Flem yapmak i\u00E7in fare ile t\u0131klayarak bir elemanı se\u00E7ili duruma getiriniz.',
addDocMenu:'Dosya ekle',
addFolderMenu:'Klas\u00F6r ekle',
editMenu:'D\u00FCzenle',
deleteMenu:'Sil',
missionCompleted:'\u0130\u015Flem ba\u015Far\u0131yla tamamland\u0131.',
expandAll:'Klas\u00F6rleri a\u00E7',
collapseAll:'Klas\u00F6rleri kapat'
});

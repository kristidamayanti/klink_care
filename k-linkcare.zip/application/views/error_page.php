<body>
    <div class="container">
        <div class="masthead">
            <div class="logo"><img alt="" src="../images/logo.png"> </div>
            <h3 class="muted"></h3>
            <div class="navbar">
                <div class="navbar-inner">
                    <div class="container">
                        <?php
                        if (count($menu) > 0):
                            echo "<ul class='nav'>";
                            foreach ($menu->result() as $row):
                                echo '<li>' . anchor($row->menu_url, $row->menu_title) . '</li>';
                            endforeach;
                            echo '</ul>';                                                           
                        endif;
                        ?>
                    </div>
                </div>
            </div><!-- /.navbar -->
        </div>

        <!-- Example row of columns -->
        <div class="row-fluid">
            <div class="span12 subnav">
                <div class="alex menu"><h2>We are sorry !</h2></div>                  
            </div>
        </div>

        <div class="row-fluid">
            <div class="span12">
                <!-- Jumbotron -->
                <div class="jumbotron">
                    <div class="donatebg">
                        <?php echo img("images/404.png"); ?>                            
                    </div>
                </div>
            </div>
        </div>

        <hr>

        <div class="footer">
            <p>&copy; K-Link Care Foundation 2013 - 2013</p>
        </div>

    </div> <!-- /container -->

    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo base_url(); ?>bootstrap/js/jquery-1.10.2.min.js"></script>
    <script src="<?php echo base_url(); ?>bootstrap/js/bootstrap.js"></script>    
    <script src="<?php echo base_url(); ?>bootstrap/js/jquery.backstretch.min.js"></script>
    <script type="text/javascript">
        $.backstretch("<?php echo base_url(); ?>images/bg.jpg");
    </script>
</body>
</html>


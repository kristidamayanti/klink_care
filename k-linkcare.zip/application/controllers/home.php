<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of home
 *
 * @author sahid
 */
class home extends CI_Controller {

    //put your code here
    public function Home() {
        parent::__construct();
		//$this->load->model('menu_model');
		$this->load->model('m_menu'); 
    }
    
    public function index() {
		$data['listMenu'] = $this->m_menu->getAllMenuHead();
		//$data['listMenuChild'] = $this->m_menu->getChildMenu();
		$this->load->view('vcare/include/header.php');
        //$this->load->view('vcare/v_utama', $data); hilal
		//nandang
		$data['listImgHdr']=$this->m_menu->getImgHeader();
        $this->load->view('vcare/v_utama',$data);
		
		$this->load->view('vcare/include/footer.php');
    }

}

<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of menu_model
 *
 * @author sahid
 */
class menu_model extends CI_Model{
    //put your code here
    
    public function getHeaderMenu(){
//        Mengambil field di table menu 
//        untuk ditampilkan sebagai menu
        
        $this->db->select('menu_title,menu_url');
        $query = $this->db->get('menu');
        
        if ($query->num_rows() > 0):
            return $query;
        else:
            return NULL;
        endif;
    }
    
    public function getChildMenu($menu_category){
//        Mengambil field di table menu_child 
//        untuk ditampilkan sebagai sub menu
        
        $this->db->select('menu_title','menu_url');
        $this->db->where('menu_category',$menu_category);
        $query = $this->db->get('menu_child');
        
        if ($query->num_rows() > 0):
            return $query;
        else:
            return NULL;
        endif;
    }
    
	public function getImgHeader(){
		$query=$this->db->query('SELECT * from ImgHeader order by ImgId desc');
		if($query->num_rows > 0 )
		{
			foreach($query->result() as $data)
			{
				$hasil[]=$data;
			}
			return $hasil;
		}
	}
    
}

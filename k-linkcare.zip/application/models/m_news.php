<?php
class M_news extends CI_Model{

	public function getAllNews($limit, $offset){
		$data = $this->input->post(NULL, TRUE);
		//$qry = "SELECT * FROM news ORDER BY news_id desc LIMIT $limit, $offset";
		//$query = $this->db->query($qry);
		$this->db->order_by('news_id','desc');
		$query=$this->db->get('news',$limit,$offset);
    	return $query->result_object();
	}  
	
	public function getAllNews2(){
		$data = $this->input->post(NULL, TRUE);
		$qry = "SELECT * FROM news ORDER BY news_id desc";
		$query = $this->db->query($qry);
    	return $query->result_object();
	}  
	
	public function getNewsByID($news_id){
		$data = $this->input->post(NULL, TRUE);
		$qry = "SELECT * FROM news WHERE news_id='$news_id' ORDER BY news_id desc";
		$query = $this->db->query($qry);
    	return $query->result_object();
	}  
}

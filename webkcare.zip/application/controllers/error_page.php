<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of 404
 *
 * @author sahid
 */
class error_page extends CI_Controller {

    //put your code here
    public function error_page() {
        parent::__construct();
//        Load class model menu model
        $this->load->model('menu_model','menu');
    }
    
    public function index() {
        $data['titlepage'] = 'Error Page';
        $data['menu'] = $this->menu->getHeaderMenu();
        
        $this->load->view('html_config',$data);
        $this->load->view('error_page',$data);
    }

}

<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of home
 *
 * @author sahid
 */
class home extends CI_Controller {

    //put your code here
    public function Home() {
        parent::__construct();
		$this->load->helper('text');
		$this->load->model('m_menu'); 
		$this->load->model('m_news');
    }
    
    public function index() {
		$data['listMenu'] = $this->m_menu->getAllMenuHead();
		$data['listNews']=$this->m_news->getAllNews(1,1);
		//$data['listMenuChild'] = $this->m_menu->getChildMenu();
		$this->load->view('vcare/include/header.php');
        //$this->load->view('vcare/v_utama', $data); hilal
		//nandang
		$data['listImgHdr']=$this->m_menu->getImgHeader();
        $this->load->view('vcare/v_utama',$data);
		
		$this->load->view('vcare/include/footer.php');
    }

}
